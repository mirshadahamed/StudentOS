(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_components_ActivityPage_jsx_fd418812._.js",
  "static/chunks/node_modules_b93a0887._.js"
],
    source: "dynamic"
});
